  import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://pyltyiubzupqopajuprh.supabase.co',
    anonKey: 'sb_publishable_ig2r99nQ6T_D-PKQhbL2Jg_0W9w7jj9',
  );
  runApp(const VertexApp());
}
final supa = Supabase.instance.client;

class VertexApp extends StatelessWidget { 
  const VertexApp({super.key});
  @override Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, 
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: Colors.black),
      home: supa.auth.currentSession == null ? const WelcomeAnimada() : const HomePage()
    );
  }
}

class WelcomeAnimada extends StatefulWidget { const WelcomeAnimada({super.key}); @override State<WelcomeAnimada> createState()=> _WState(); }
class _WState extends State<WelcomeAnimada> with SingleTickerProviderStateMixin {
  late AnimationController c; 
  @override void initState(){ super.initState(); c=AnimationController(vsync:this, duration:const Duration(seconds:4))..repeat(reverse:true); } 
  @override void dispose(){ c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context){
    return Scaffold(body: AnimatedBuilder(animation:c, builder:(context,_)=> Container(
      decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(Colors.purple.shade900, Colors.black, c.value)!, Color.lerp(Colors.blue.shade900, Colors.black, 1-c.value)!])),
      child: Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(mainAxisAlignment:MainAxisAlignment.center, children:[
        Icon(Icons.diamond, size: 80+20*c.value, color: Colors.white), const SizedBox(height:20),
        const Text('VERTEX', style: TextStyle(fontSize:48, fontWeight:FontWeight.bold, letterSpacing:6)), 
        const Text('Privado. Tuyo. Sin rastros.', style:TextStyle(color:Colors.white54)),
        const SizedBox(height:80),
        SizedBox(width:double.infinity, child: ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder:(_)=> const RegisterPage())), style: ElevatedButton.styleFrom(backgroundColor:Colors.white, foregroundColor:Colors.black, padding:const EdgeInsets.all(18), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(30))), child: const Text('Crear cuenta', style:TextStyle(fontWeight:FontWeight.bold)))),
        const SizedBox(height:15),
        SizedBox(width:double.infinity, child: OutlinedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder:(_)=> const LoginPage())), style: OutlinedButton.styleFrom(foregroundColor:Colors.white, side:const BorderSide(color:Colors.white54), padding:const EdgeInsets.all(18), shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(30))), child: const Text('Ya tengo cuenta'))),
      ]))),)));
  }
}

class RegisterPage extends StatefulWidget { const RegisterPage({super.key}); @override State<RegisterPage> createState()=> _RState(); }
class _RState extends State<RegisterPage> {
  final email=TextEditingController(), user=TextEditingController(), pass=TextEditingController(); bool load=false;
  reg() async { 
    if(user.text.trim().isEmpty) return; 
    setState(()=>load=true); 
    try{ 
      final res=await supa.auth.signUp(email:email.text.trim(), password:pass.text.trim()); 
      await supa.from('profiles').insert({'id':res.user!.id,'username':user.text.trim().toLowerCase()}); 
      if(mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder:(_)=> const HomePage()),(r)=>false); 
    } on PostgrestException catch(e){ 
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.code=='23505'?'Ese usuario YA existe':'Error: ${e.message}')));
    } catch(e){ 
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Error: $e')));
    } 
    setState(()=>load=false); 
  }
  @override Widget build(BuildContext c)=> Scaffold(appBar:AppBar(title:const Text('Crear cuenta')), body:Padding(padding:const EdgeInsets.all(20), child:Column(children:[TextField(controller:email, decoration:const InputDecoration(labelText:'Email')), TextField(controller:user, decoration:const InputDecoration(labelText:'Username único ej: davo')), TextField(controller:pass, obscureText:true, decoration:const InputDecoration(labelText:'Contraseña')), const SizedBox(height:20), load?const CircularProgressIndicator():ElevatedButton(onPressed:reg, child:const Text('Registrarme'))])));
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=> _LState(); }
class _LState extends State<LoginPage> {
  final email=TextEditingController(), pass=TextEditingController(); bool load=false;
  login() async { setState(()=>load=true); try{ await supa.auth.signInWithPassword(email:email.text.trim(), password:pass.text.trim()); if(mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder:(_)=> const HomePage()),(r)=>false);} catch(e){ ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Error: $e')));} setState(()=>load=false); }
  @override Widget build(BuildContext c)=> Scaffold(appBar:AppBar(title:const Text('Entrar')), body:Padding(padding:const EdgeInsets.all(20), child:Column(children:[TextField(controller:email, decoration:const InputDecoration(labelText:'Email')), TextField(controller:pass, obscureText:true, decoration:const InputDecoration(labelText:'Contraseña')), const SizedBox(height:20), load?const CircularProgressIndicator():ElevatedButton(onPressed:login, child:const Text('Entrar'))])));
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=> _HState(); }
class _HState extends State<HomePage> {
  int idx=0; List profiles=[]; List filtered=[]; final search=TextEditingController(); final msgCtrl=TextEditingController(); List msgs=[]; Color chatBg=Colors.black;
  @override void initState(){ super.initState(); loadProfiles(); loadMsgs(); search.addListener(()=> setState(()=> filtered=profiles.where((p)=>p['username'].toString().toLowerCase().contains(search.text.toLowerCase())).toList())); }
  loadProfiles() async { final d=await supa.from('profiles').select(); setState((){profiles=d; filtered=d;}); }
  loadMsgs() async { final d=await supa.from('messages').select().order('created_at'); setState(()=>msgs=d); supa.from('messages').stream(primaryKey:['id']).order('created_at').listen((data){ setState(()=>msgs=data); }); }
  send() async { if(msgCtrl.text.trim().isEmpty) return; await supa.from('messages').insert({'content':msgCtrl.text.trim(),'user_id':supa.auth.currentUser!.id}); msgCtrl.clear(); }
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title:const Text('VERTEX'), actions:[IconButton(onPressed: ()=> showModalBottomSheet(context:context, builder:(_)=>Container(height:150, color:Colors.grey[900], child:Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly, children:[ _bgBtn(Colors.black), _bgBtn(Colors.blue.shade900), _bgBtn(Colors.purple.shade900), _bgBtn(const Color(0xFF121212))]))), icon:const Icon(Icons.palette)), IconButton(onPressed: ()=> supa.auth.signOut().then((_)=> Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder:(_)=> const WelcomeAnimada()),(r)=>false)), icon:const Icon(Icons.logout))]),
      body: idx==0? Container(color:chatBg, child:Column(children:[Expanded(child:ListView.builder(itemCount:msgs.length, itemBuilder:(c,i){ final m=msgs[i]; final mine=m['user_id']==supa.auth.currentUser!.id; return Align(alignment: mine?Alignment.centerRight:Alignment.centerLeft, child:Container(margin:const EdgeInsets.all(6), padding:const EdgeInsets.all(12), decoration:BoxDecoration(color: mine?Colors.white:Colors.grey[800], borderRadius:BorderRadius.circular(18)), child:Text(m['content'], style:TextStyle(color:mine?Colors.black:Colors.white)))); })), Padding(padding:const EdgeInsets.all(8), child:Row(children:[Expanded(child:TextField(controller:msgCtrl, decoration:InputDecoration(hintText:'Mensaje...', filled:true, fillColor:Colors.grey[900], border:OutlineInputBorder(borderRadius:BorderRadius.circular(30))))), IconButton(onPressed:send, icon:const Icon(Icons.send, color:Colors.white))]))])) : idx==1? Column(children:[Padding(padding:const EdgeInsets.all(10), child:TextField(controller:search, decoration:const InputDecoration(prefixIcon:Icon(Icons.search), hintText:'Buscar personas...', border:OutlineInputBorder()))), Expanded(child:ListView.builder(itemCount:filtered.length, itemBuilder:(c,i){ final p=filtered[i]; return ListTile(leading:CircleAvatar(backgroundImage:p['avatar_url']!=null?NetworkImage(p['avatar_url']):null, child:p['avatar_url']==null?Text(p['username'][0].toUpperCase()):null), title:Text(p['username']), subtitle:Text(p['bio']??''), onTap: ()=> Navigator.push(context, MaterialPageRoute(builder:(_)=> ProfileView(p:p)))); }))]) : const MyProfile(),
      bottomNavigationBar: BottomNavigationBar(currentIndex:idx, onTap:(i)=>setState(()=>idx=i), items:const[BottomNavigationBarItem(icon:Icon(Icons.chat),label:'Chat'), BottomNavigationBarItem(icon:Icon(Icons.people),label:'Contactos'), BottomNavigationBarItem(icon:Icon(Icons.person),label:'Perfil')]),
    );
  }
  Widget _bgBtn(Color col)=> GestureDetector(onTap:(){setState(()=>chatBg=col); Navigator.pop(context);}, child:CircleAvatar(backgroundColor:col, radius:25));
}

class ProfileView extends StatelessWidget { 
  final Map p; 
  const ProfileView({super.key, required this.p}); 
  @override 
  Widget build(BuildContext context){ 
    return Scaffold(
      appBar: AppBar(title: Text(p['username'])), 
      body: Column(children:[
        const SizedBox(height:30), 
        Center(child:CircleAvatar(radius:50, backgroundImage:p['avatar_url']!=null?NetworkImage(p['avatar_url']):null)), 
        const SizedBox(height:10), 
        Text(p['username'], style:const TextStyle(fontSize:22, fontWeight:FontWeight.bold)), 
        Text(p['bio']??'', style:const TextStyle(color:Colors.grey))
      ])
    ); 
  } 
}

class MyProfile extends StatefulWidget { const MyProfile({super.key}); @override State<MyProfile> createState()=> _MPState(); }
class _MPState extends State<MyProfile> {
  Map? me; bool load=true;
  @override void initState(){ super.initState(); getMe(); }
  getMe() async { final d=await supa.from('profiles').select().eq('id', supa.auth.currentUser!.id).single(); setState((){me=d; load=false;}); }
  pick() async { 
    final XFile? img=await ImagePicker().pickImage(source:ImageSource.gallery); 
    if(img==null) return; 
    final bytes=await img.readAsBytes(); 
    final name='${supa.auth.currentUser!.id}.png'; 
    await supa.storage.from('avatars').uploadBinary(name, bytes, fileOptions:const FileOptions(upsert:true)); 
    final url=supa.storage.from('avatars').getPublicUrl(name); 
    await supa.from('profiles').update({'avatar_url':url}).eq('id', supa.auth.currentUser!.id); 
    getMe(); 
  }
  @override Widget build(BuildContext c)=> load?const Center(child:CircularProgressIndicator()):Column(children:[const SizedBox(height:30), GestureDetector(onTap:pick, child:CircleAvatar(radius:50, backgroundImage:me!['avatar_url']!=null?NetworkImage(me!['avatar_url']):null, child:me!['avatar_url']==null?const Icon(Icons.camera_alt, size:40):null)), const SizedBox(height:10), Text(me!['username'], style:const TextStyle(fontSize:22)), Text(me!['bio']??''), const SizedBox(height:10), const Text('Toca la foto para subir foto', style:TextStyle(color:Colors.grey, fontSize:12))]);
}